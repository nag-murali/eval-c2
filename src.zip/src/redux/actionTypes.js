export const SEARCH = "SEARCH";

export const ALPHA_ASC = "ALPHA_ASC";

export const ALPHA_DESC = "ALPHA_DESC";

export const QUALITY_ASC = "QUALITY_ASC";

export const QUALITY_DESC = "QUALITY_DESC";